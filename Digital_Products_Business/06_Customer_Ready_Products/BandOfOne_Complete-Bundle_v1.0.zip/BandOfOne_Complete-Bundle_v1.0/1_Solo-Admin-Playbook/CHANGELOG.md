# Changelog: The Solo Admin Playbook

## 1.0 (2026-09-24)

- First release.
- Included files:
  - `BandOfOne_Solo-Admin-Playbook_v1.0.pdf`
  - `BandOfOne_Solo-Admin-Playbook_v1.0_editable.docx`
  - `START-HERE.pdf`, `LICENSE.txt`, `CHANGELOG.md`
