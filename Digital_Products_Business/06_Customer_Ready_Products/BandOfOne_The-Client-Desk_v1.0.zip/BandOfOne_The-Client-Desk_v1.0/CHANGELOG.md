# Changelog: The Client Desk

## 1.0 (2026-09-24)

- First release.
- Included files:
  - `BandOfOne_The-Client-Desk_v1.0.xlsx`
  - `BandOfOne_The-Client-Desk_User-Guide_v1.0.pdf`
  - `START-HERE.pdf`, `LICENSE.txt`, `CHANGELOG.md`
