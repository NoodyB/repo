# Changelog: The Band of One Prompt Library

## 1.0 (2026-09-24)

- First release.
- Included files:
  - `BandOfOne_Prompt-Library_v1.0.pdf`
  - `BandOfOne_Prompt-Library_v1.0_Searchable.xlsx`
  - `BandOfOne_Prompt-Library_v1.0.csv`
  - `BandOfOne_Prompt-Library_v1.0_editable.docx`
  - `BandOfOne_Prompt-Library_v1.0.md`
  - `START-HERE.pdf`, `LICENSE.txt`, `CHANGELOG.md`
